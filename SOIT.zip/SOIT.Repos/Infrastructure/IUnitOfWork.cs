﻿namespace SOIT.Repos.Infrastructure
{
    public interface IUnitOfWork
    {
        void Commit();
    }
}
