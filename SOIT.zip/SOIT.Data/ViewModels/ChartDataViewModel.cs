﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOIT.Data.ViewModels
{
    public class ChartDataViewModel
    {
        public string SeriesName { get; set; }
        public List<int> SeriesData { get; set; }
    }
}
