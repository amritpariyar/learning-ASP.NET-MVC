/**
 * @license Highcharts JS v7.2.1 (2019-10-31)
 * @module highcharts/modules/broken-axis
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/broken-axis.src.js';
